#!/bin/sh
PATH=$PATH:bin

mkdir dump
cray_xmp_sim cos_117.cfg

